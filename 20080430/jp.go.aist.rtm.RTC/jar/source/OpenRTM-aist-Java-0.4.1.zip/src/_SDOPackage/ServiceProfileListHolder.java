package _SDOPackage;


/**
* _SDOPackage/ServiceProfileListHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 11��46��37�b JST
*/

public final class ServiceProfileListHolder implements org.omg.CORBA.portable.Streamable
{
  public _SDOPackage.ServiceProfile value[] = null;

  public ServiceProfileListHolder ()
  {
  }

  public ServiceProfileListHolder (_SDOPackage.ServiceProfile[] initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = _SDOPackage.ServiceProfileListHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    _SDOPackage.ServiceProfileListHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return _SDOPackage.ServiceProfileListHelper.type ();
  }

}
