package RTC;

/**
* RTC/PortInterfaceProfileHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 11��46��38�b JST
*/

public final class PortInterfaceProfileHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.PortInterfaceProfile value = null;

  public PortInterfaceProfileHolder ()
  {
  }

  public PortInterfaceProfileHolder (RTC.PortInterfaceProfile initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.PortInterfaceProfileHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.PortInterfaceProfileHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.PortInterfaceProfileHelper.type ();
  }

}
