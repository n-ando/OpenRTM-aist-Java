package RTC;


/**
* RTC/PortProfile.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 11��46��38�b JST
*/

public final class PortProfile implements org.omg.CORBA.portable.IDLEntity
{
  public String name = null;
  public RTC.PortInterfaceProfile interfaces[] = null;
  public RTC.Port port_ref = null;
  public RTC.ConnectorProfile connector_profiles[] = null;
  public RTC.RTObject owner = null;
  public _SDOPackage.NameValue properties[] = null;

  public PortProfile ()
  {
  } // ctor

  public PortProfile (String _name, RTC.PortInterfaceProfile[] _interfaces, RTC.Port _port_ref, RTC.ConnectorProfile[] _connector_profiles, RTC.RTObject _owner, _SDOPackage.NameValue[] _properties)
  {
    name = _name;
    interfaces = _interfaces;
    port_ref = _port_ref;
    connector_profiles = _connector_profiles;
    owner = _owner;
    properties = _properties;
  } // ctor

} // class PortProfile
