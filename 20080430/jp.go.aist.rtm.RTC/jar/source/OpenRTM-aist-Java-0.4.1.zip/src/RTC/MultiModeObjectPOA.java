package RTC;


/**
* RTC/MultiModeObjectPOA.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 11��46��38�b JST
*/


/*!
   * @brief ExecutionSemantics::MultiModeObject interface
   */
public abstract class MultiModeObjectPOA extends org.omg.PortableServer.Servant
 implements RTC.MultiModeObjectOperations, org.omg.CORBA.portable.InvokeHandler
{

  // Constructors

  private static java.util.Hashtable _methods = new java.util.Hashtable ();
  static
  {
    _methods.put ("get_default_mode", new java.lang.Integer (0));
    _methods.put ("get_current_mode", new java.lang.Integer (1));
    _methods.put ("get_current_mode_in_context", new java.lang.Integer (2));
    _methods.put ("get_pending_mode", new java.lang.Integer (3));
    _methods.put ("get_pending_mode_in_context", new java.lang.Integer (4));
    _methods.put ("set_mode", new java.lang.Integer (5));
    _methods.put ("on_mode_changed", new java.lang.Integer (6));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (String $method,
                                org.omg.CORBA.portable.InputStream in,
                                org.omg.CORBA.portable.ResponseHandler $rh)
  {
    org.omg.CORBA.portable.OutputStream out = null;
    java.lang.Integer __method = (java.lang.Integer)_methods.get ($method);
    if (__method == null)
      throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);

    switch (__method.intValue ())
    {
       case 0:  // RTC/ModeCapable/get_default_mode
       {
         RTC.Mode $result = null;
         $result = this.get_default_mode ();
         out = $rh.createReply();
         RTC.ModeHelper.write (out, $result);
         break;
       }

       case 1:  // RTC/ModeCapable/get_current_mode
       {
         RTC.Mode $result = null;
         $result = this.get_current_mode ();
         out = $rh.createReply();
         RTC.ModeHelper.write (out, $result);
         break;
       }

       case 2:  // RTC/ModeCapable/get_current_mode_in_context
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.Mode $result = null;
         $result = this.get_current_mode_in_context (ec_id);
         out = $rh.createReply();
         RTC.ModeHelper.write (out, $result);
         break;
       }

       case 3:  // RTC/ModeCapable/get_pending_mode
       {
         RTC.Mode $result = null;
         $result = this.get_pending_mode ();
         out = $rh.createReply();
         RTC.ModeHelper.write (out, $result);
         break;
       }

       case 4:  // RTC/ModeCapable/get_pending_mode_in_context
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.Mode $result = null;
         $result = this.get_pending_mode_in_context (ec_id);
         out = $rh.createReply();
         RTC.ModeHelper.write (out, $result);
         break;
       }

       case 5:  // RTC/ModeCapable/set_mode
       {
         RTC.Mode new_mode = RTC.ModeHelper.read (in);
         boolean immediate = in.read_boolean ();
         RTC.ReturnCode_t $result = null;
         $result = this.set_mode (new_mode, immediate);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 6:  // RTC/MultiModeComponentAction/on_mode_changed
       {
         RTC.LightweightRTObject comp = RTC.LightweightRTObjectHelper.read (in);
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_mode_changed (comp, ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       default:
         throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
    }

    return out;
  } // _invoke

  // Type-specific CORBA::Object operations
  private static String[] __ids = {
    "IDL:omg.org/RTC/MultiModeObject:1.0", 
    "IDL:omg.org/RTC/ModeCapable:1.0", 
    "IDL:omg.org/RTC/MultiModeComponentAction:1.0"};

  public String[] _all_interfaces (org.omg.PortableServer.POA poa, byte[] objectId)
  {
    return (String[])__ids.clone ();
  }

  public MultiModeObject _this() 
  {
    return MultiModeObjectHelper.narrow(
    super._this_object());
  }

  public MultiModeObject _this(org.omg.CORBA.ORB orb) 
  {
    return MultiModeObjectHelper.narrow(
    super._this_object(orb));
  }


} // class MultiModeObjectPOA
