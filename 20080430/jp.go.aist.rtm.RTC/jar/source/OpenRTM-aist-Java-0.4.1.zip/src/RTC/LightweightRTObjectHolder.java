package RTC;

/**
* RTC/LightweightRTObjectHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 11��46��38�b JST
*/


/*!
   * @brief LightweightRTC::LightweightRTObject interface
   */
public final class LightweightRTObjectHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.LightweightRTObject value = null;

  public LightweightRTObjectHolder ()
  {
  }

  public LightweightRTObjectHolder (RTC.LightweightRTObject initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.LightweightRTObjectHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.LightweightRTObjectHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.LightweightRTObjectHelper.type ();
  }

}
