package RTC;

/**
* RTC/ComponentActionHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 11��46��38�b JST
*/


/*!
   * @brief LightweightRTC::ConponentAction interface
   */
public final class ComponentActionHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.ComponentAction value = null;

  public ComponentActionHolder ()
  {
  }

  public ComponentActionHolder (RTC.ComponentAction initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.ComponentActionHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.ComponentActionHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.ComponentActionHelper.type ();
  }

}
