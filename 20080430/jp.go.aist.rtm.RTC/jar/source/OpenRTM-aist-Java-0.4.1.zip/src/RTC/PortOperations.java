package RTC;


/**
* RTC/PortOperations.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 11��46��38�b JST
*/


/*!
   * @brief Introspection::Port interface
   */
public interface PortOperations  extends _SDOPackage.SDOServiceOperations
{
  RTC.PortProfile get_port_profile ();
  RTC.ConnectorProfile[] get_connector_profiles ();
  RTC.ConnectorProfile get_connector_profile (String connector_id);
  RTC.ReturnCode_t connect (RTC.ConnectorProfileHolder connector_profile);
  RTC.ReturnCode_t notify_connect (RTC.ConnectorProfileHolder connector_profile);
  RTC.ReturnCode_t disconnect (String connector_id);
  RTC.ReturnCode_t notify_disconnect (String connector_id);
  RTC.ReturnCode_t disconnect_all ();
} // interface PortOperations
