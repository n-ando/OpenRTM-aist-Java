package RTC;


/**
* RTC/DataFlowMultiModeComponentPOA.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 11��46��38�b JST
*/

public abstract class DataFlowMultiModeComponentPOA extends org.omg.PortableServer.Servant
 implements RTC.DataFlowMultiModeComponentOperations, org.omg.CORBA.portable.InvokeHandler
{

  // Constructors

  private static java.util.Hashtable _methods = new java.util.Hashtable ();
  static
  {
    _methods.put ("get_component_profile", new java.lang.Integer (0));
    _methods.put ("get_ports", new java.lang.Integer (1));
    _methods.put ("get_execution_context_services", new java.lang.Integer (2));
    _methods.put ("initialize", new java.lang.Integer (3));
    _methods.put ("finalize", new java.lang.Integer (4));
    _methods.put ("exit", new java.lang.Integer (5));
    _methods.put ("is_alive", new java.lang.Integer (6));
    _methods.put ("get_contexts", new java.lang.Integer (7));
    _methods.put ("get_context", new java.lang.Integer (8));
    _methods.put ("attach_executioncontext", new java.lang.Integer (9));
    _methods.put ("detach_executioncontext", new java.lang.Integer (10));
    _methods.put ("on_initialize", new java.lang.Integer (11));
    _methods.put ("on_finalize", new java.lang.Integer (12));
    _methods.put ("on_startup", new java.lang.Integer (13));
    _methods.put ("on_shutdown", new java.lang.Integer (14));
    _methods.put ("on_activated", new java.lang.Integer (15));
    _methods.put ("on_deactivated", new java.lang.Integer (16));
    _methods.put ("on_aborting", new java.lang.Integer (17));
    _methods.put ("on_error", new java.lang.Integer (18));
    _methods.put ("on_reset", new java.lang.Integer (19));
    _methods.put ("get_sdo_id", new java.lang.Integer (20));
    _methods.put ("get_sdo_type", new java.lang.Integer (21));
    _methods.put ("get_device_profile", new java.lang.Integer (22));
    _methods.put ("get_service_profiles", new java.lang.Integer (23));
    _methods.put ("get_service_profile", new java.lang.Integer (24));
    _methods.put ("get_sdo_service", new java.lang.Integer (25));
    _methods.put ("get_configuration", new java.lang.Integer (26));
    _methods.put ("get_monitoring", new java.lang.Integer (27));
    _methods.put ("get_organizations", new java.lang.Integer (28));
    _methods.put ("get_status_list", new java.lang.Integer (29));
    _methods.put ("get_status", new java.lang.Integer (30));
    _methods.put ("get_owned_organizations", new java.lang.Integer (31));
    _methods.put ("on_execute", new java.lang.Integer (32));
    _methods.put ("on_state_update", new java.lang.Integer (33));
    _methods.put ("on_rate_changed", new java.lang.Integer (34));
    _methods.put ("get_default_mode", new java.lang.Integer (35));
    _methods.put ("get_current_mode", new java.lang.Integer (36));
    _methods.put ("get_current_mode_in_context", new java.lang.Integer (37));
    _methods.put ("get_pending_mode", new java.lang.Integer (38));
    _methods.put ("get_pending_mode_in_context", new java.lang.Integer (39));
    _methods.put ("set_mode", new java.lang.Integer (40));
    _methods.put ("on_mode_changed", new java.lang.Integer (41));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (String $method,
                                org.omg.CORBA.portable.InputStream in,
                                org.omg.CORBA.portable.ResponseHandler $rh)
  {
    org.omg.CORBA.portable.OutputStream out = null;
    java.lang.Integer __method = (java.lang.Integer)_methods.get ($method);
    if (__method == null)
      throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);

    switch (__method.intValue ())
    {
       case 0:  // RTC/RTObject/get_component_profile
       {
         RTC.ComponentProfile $result = null;
         $result = this.get_component_profile ();
         out = $rh.createReply();
         RTC.ComponentProfileHelper.write (out, $result);
         break;
       }

       case 1:  // RTC/RTObject/get_ports
       {
         RTC.Port $result[] = null;
         $result = this.get_ports ();
         out = $rh.createReply();
         RTC.PortListHelper.write (out, $result);
         break;
       }

       case 2:  // RTC/RTObject/get_execution_context_services
       {
         RTC.ExecutionContextService $result[] = null;
         $result = this.get_execution_context_services ();
         out = $rh.createReply();
         RTC.ExecutionContextServiceListHelper.write (out, $result);
         break;
       }

       case 3:  // RTC/LightweightRTObject/initialize
       {
         RTC.ReturnCode_t $result = null;
         $result = this.initialize ();
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 4:  // RTC/LightweightRTObject/_finalize
       {
         RTC.ReturnCode_t $result = null;
         $result = this._finalize ();
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 5:  // RTC/LightweightRTObject/exit
       {
         RTC.ReturnCode_t $result = null;
         $result = this.exit ();
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 6:  // RTC/LightweightRTObject/is_alive
       {
         boolean $result = false;
         $result = this.is_alive ();
         out = $rh.createReply();
         out.write_boolean ($result);
         break;
       }

       case 7:  // RTC/LightweightRTObject/get_contexts
       {
         RTC.ExecutionContext $result[] = null;
         $result = this.get_contexts ();
         out = $rh.createReply();
         RTC.ExecutionContextListHelper.write (out, $result);
         break;
       }

       case 8:  // RTC/LightweightRTObject/get_context
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ExecutionContext $result = null;
         $result = this.get_context (ec_id);
         out = $rh.createReply();
         RTC.ExecutionContextHelper.write (out, $result);
         break;
       }

       case 9:  // RTC/ComponentAction/attach_executioncontext
       {
         RTC.ExecutionContext exec_context = RTC.ExecutionContextHelper.read (in);
         int $result = (int)0;
         $result = this.attach_executioncontext (exec_context);
         out = $rh.createReply();
         out.write_long ($result);
         break;
       }

       case 10:  // RTC/ComponentAction/detach_executioncontext
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.detach_executioncontext (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 11:  // RTC/ComponentAction/on_initialize
       {
         RTC.ReturnCode_t $result = null;
         $result = this.on_initialize ();
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 12:  // RTC/ComponentAction/on_finalize
       {
         RTC.ReturnCode_t $result = null;
         $result = this.on_finalize ();
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 13:  // RTC/ComponentAction/on_startup
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_startup (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 14:  // RTC/ComponentAction/on_shutdown
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_shutdown (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 15:  // RTC/ComponentAction/on_activated
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_activated (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 16:  // RTC/ComponentAction/on_deactivated
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_deactivated (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 17:  // RTC/ComponentAction/on_aborting
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_aborting (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 18:  // RTC/ComponentAction/on_error
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_error (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 19:  // RTC/ComponentAction/on_reset
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_reset (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 20:  // _SDOPackage/SDO/get_sdo_id
       {
         try {
           String $result = null;
           $result = this.get_sdo_id ();
           out = $rh.createReply();
           out.write_string ($result);
         } catch (_SDOPackage.NotAvailable $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.NotAvailableHelper.write (out, $ex);
         } catch (_SDOPackage.InternalError $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.InternalErrorHelper.write (out, $ex);
         }
         break;
       }

       case 21:  // _SDOPackage/SDO/get_sdo_type
       {
         try {
           String $result = null;
           $result = this.get_sdo_type ();
           out = $rh.createReply();
           out.write_string ($result);
         } catch (_SDOPackage.NotAvailable $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.NotAvailableHelper.write (out, $ex);
         } catch (_SDOPackage.InternalError $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.InternalErrorHelper.write (out, $ex);
         }
         break;
       }

       case 22:  // _SDOPackage/SDO/get_device_profile
       {
         try {
           _SDOPackage.DeviceProfile $result = null;
           $result = this.get_device_profile ();
           out = $rh.createReply();
           _SDOPackage.DeviceProfileHelper.write (out, $result);
         } catch (_SDOPackage.NotAvailable $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.NotAvailableHelper.write (out, $ex);
         } catch (_SDOPackage.InternalError $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.InternalErrorHelper.write (out, $ex);
         }
         break;
       }

       case 23:  // _SDOPackage/SDO/get_service_profiles
       {
         try {
           _SDOPackage.ServiceProfile $result[] = null;
           $result = this.get_service_profiles ();
           out = $rh.createReply();
           _SDOPackage.ServiceProfileListHelper.write (out, $result);
         } catch (_SDOPackage.NotAvailable $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.NotAvailableHelper.write (out, $ex);
         } catch (_SDOPackage.InternalError $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.InternalErrorHelper.write (out, $ex);
         }
         break;
       }

       case 24:  // _SDOPackage/SDO/get_service_profile
       {
         try {
           String id = _SDOPackage.UniqueIdentifierHelper.read (in);
           _SDOPackage.ServiceProfile $result = null;
           $result = this.get_service_profile (id);
           out = $rh.createReply();
           _SDOPackage.ServiceProfileHelper.write (out, $result);
         } catch (_SDOPackage.InvalidParameter $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.InvalidParameterHelper.write (out, $ex);
         } catch (_SDOPackage.NotAvailable $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.NotAvailableHelper.write (out, $ex);
         } catch (_SDOPackage.InternalError $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.InternalErrorHelper.write (out, $ex);
         }
         break;
       }

       case 25:  // _SDOPackage/SDO/get_sdo_service
       {
         try {
           String id = _SDOPackage.UniqueIdentifierHelper.read (in);
           _SDOPackage.SDOService $result = null;
           $result = this.get_sdo_service (id);
           out = $rh.createReply();
           _SDOPackage.SDOServiceHelper.write (out, $result);
         } catch (_SDOPackage.InvalidParameter $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.InvalidParameterHelper.write (out, $ex);
         } catch (_SDOPackage.NotAvailable $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.NotAvailableHelper.write (out, $ex);
         } catch (_SDOPackage.InternalError $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.InternalErrorHelper.write (out, $ex);
         }
         break;
       }

       case 26:  // _SDOPackage/SDO/get_configuration
       {
         try {
           _SDOPackage.Configuration $result = null;
           $result = this.get_configuration ();
           out = $rh.createReply();
           _SDOPackage.ConfigurationHelper.write (out, $result);
         } catch (_SDOPackage.InterfaceNotImplemented $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.InterfaceNotImplementedHelper.write (out, $ex);
         } catch (_SDOPackage.NotAvailable $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.NotAvailableHelper.write (out, $ex);
         } catch (_SDOPackage.InternalError $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.InternalErrorHelper.write (out, $ex);
         }
         break;
       }

       case 27:  // _SDOPackage/SDO/get_monitoring
       {
         try {
           _SDOPackage.Monitoring $result = null;
           $result = this.get_monitoring ();
           out = $rh.createReply();
           _SDOPackage.MonitoringHelper.write (out, $result);
         } catch (_SDOPackage.InterfaceNotImplemented $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.InterfaceNotImplementedHelper.write (out, $ex);
         } catch (_SDOPackage.NotAvailable $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.NotAvailableHelper.write (out, $ex);
         } catch (_SDOPackage.InternalError $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.InternalErrorHelper.write (out, $ex);
         }
         break;
       }

       case 28:  // _SDOPackage/SDO/get_organizations
       {
         try {
           _SDOPackage.Organization $result[] = null;
           $result = this.get_organizations ();
           out = $rh.createReply();
           _SDOPackage.OrganizationListHelper.write (out, $result);
         } catch (_SDOPackage.NotAvailable $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.NotAvailableHelper.write (out, $ex);
         } catch (_SDOPackage.InternalError $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.InternalErrorHelper.write (out, $ex);
         }
         break;
       }

       case 29:  // _SDOPackage/SDO/get_status_list
       {
         try {
           _SDOPackage.NameValue $result[] = null;
           $result = this.get_status_list ();
           out = $rh.createReply();
           _SDOPackage.NVListHelper.write (out, $result);
         } catch (_SDOPackage.NotAvailable $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.NotAvailableHelper.write (out, $ex);
         } catch (_SDOPackage.InternalError $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.InternalErrorHelper.write (out, $ex);
         }
         break;
       }

       case 30:  // _SDOPackage/SDO/get_status
       {
         try {
           String name = in.read_string ();
           org.omg.CORBA.Any $result = null;
           $result = this.get_status (name);
           out = $rh.createReply();
           out.write_any ($result);
         } catch (_SDOPackage.InvalidParameter $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.InvalidParameterHelper.write (out, $ex);
         } catch (_SDOPackage.NotAvailable $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.NotAvailableHelper.write (out, $ex);
         } catch (_SDOPackage.InternalError $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.InternalErrorHelper.write (out, $ex);
         }
         break;
       }

       case 31:  // _SDOPackage/SDOSystemElement/get_owned_organizations
       {
         try {
           _SDOPackage.Organization $result[] = null;
           $result = this.get_owned_organizations ();
           out = $rh.createReply();
           _SDOPackage.OrganizationListHelper.write (out, $result);
         } catch (_SDOPackage.NotAvailable $ex) {
           out = $rh.createExceptionReply ();
           _SDOPackage.NotAvailableHelper.write (out, $ex);
         }
         break;
       }

       case 32:  // RTC/DataFlowComponentAction/on_execute
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_execute (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 33:  // RTC/DataFlowComponentAction/on_state_update
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_state_update (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 34:  // RTC/DataFlowComponentAction/on_rate_changed
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_rate_changed (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 35:  // RTC/ModeCapable/get_default_mode
       {
         RTC.Mode $result = null;
         $result = this.get_default_mode ();
         out = $rh.createReply();
         RTC.ModeHelper.write (out, $result);
         break;
       }

       case 36:  // RTC/ModeCapable/get_current_mode
       {
         RTC.Mode $result = null;
         $result = this.get_current_mode ();
         out = $rh.createReply();
         RTC.ModeHelper.write (out, $result);
         break;
       }

       case 37:  // RTC/ModeCapable/get_current_mode_in_context
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.Mode $result = null;
         $result = this.get_current_mode_in_context (ec_id);
         out = $rh.createReply();
         RTC.ModeHelper.write (out, $result);
         break;
       }

       case 38:  // RTC/ModeCapable/get_pending_mode
       {
         RTC.Mode $result = null;
         $result = this.get_pending_mode ();
         out = $rh.createReply();
         RTC.ModeHelper.write (out, $result);
         break;
       }

       case 39:  // RTC/ModeCapable/get_pending_mode_in_context
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.Mode $result = null;
         $result = this.get_pending_mode_in_context (ec_id);
         out = $rh.createReply();
         RTC.ModeHelper.write (out, $result);
         break;
       }

       case 40:  // RTC/ModeCapable/set_mode
       {
         RTC.Mode new_mode = RTC.ModeHelper.read (in);
         boolean immediate = in.read_boolean ();
         RTC.ReturnCode_t $result = null;
         $result = this.set_mode (new_mode, immediate);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 41:  // RTC/MultiModeComponentAction/on_mode_changed
       {
         RTC.LightweightRTObject comp = RTC.LightweightRTObjectHelper.read (in);
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_mode_changed (comp, ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       default:
         throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
    }

    return out;
  } // _invoke

  // Type-specific CORBA::Object operations
  private static String[] __ids = {
    "IDL:openrtm.aist.go.jp/RTC/DataFlowMultiModeComponent:1.0", 
    "IDL:omg.org/RTC/RTObject:1.0", 
    "IDL:omg.org/RTC/LightweightRTObject:1.0", 
    "IDL:omg.org/RTC/ComponentAction:1.0", 
    "IDL:org.omg/SDOPackage/SDO:1.0", 
    "IDL:org.omg/SDOPackage/SDOSystemElement:1.0", 
    "IDL:omg.org/RTC/DataFlowParticipant:1.0", 
    "IDL:omg.org/RTC/DataFlowComponentAction:1.0", 
    "IDL:omg.org/RTC/MultiModeObject:1.0", 
    "IDL:omg.org/RTC/ModeCapable:1.0", 
    "IDL:omg.org/RTC/MultiModeComponentAction:1.0"};

  public String[] _all_interfaces (org.omg.PortableServer.POA poa, byte[] objectId)
  {
    return (String[])__ids.clone ();
  }

  public DataFlowMultiModeComponent _this() 
  {
    return DataFlowMultiModeComponentHelper.narrow(
    super._this_object());
  }

  public DataFlowMultiModeComponent _this(org.omg.CORBA.ORB orb) 
  {
    return DataFlowMultiModeComponentHelper.narrow(
    super._this_object(orb));
  }


} // class DataFlowMultiModeComponentPOA
