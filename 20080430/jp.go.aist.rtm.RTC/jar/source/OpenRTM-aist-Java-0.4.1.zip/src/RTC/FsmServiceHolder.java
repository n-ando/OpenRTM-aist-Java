package RTC;

/**
* RTC/FsmServiceHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 11��46��38�b JST
*/


/*!
   * @brief Introspection::FsmService interface
   */
public final class FsmServiceHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.FsmService value = null;

  public FsmServiceHolder ()
  {
  }

  public FsmServiceHolder (RTC.FsmService initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.FsmServiceHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.FsmServiceHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.FsmServiceHelper.type ();
  }

}
