package RTC;

/**
* RTC/DataFlowFiniteStateMachineMultiModeComponentHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 11��46��38�b JST
*/

public final class DataFlowFiniteStateMachineMultiModeComponentHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.DataFlowFiniteStateMachineMultiModeComponent value = null;

  public DataFlowFiniteStateMachineMultiModeComponentHolder ()
  {
  }

  public DataFlowFiniteStateMachineMultiModeComponentHolder (RTC.DataFlowFiniteStateMachineMultiModeComponent initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.DataFlowFiniteStateMachineMultiModeComponentHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.DataFlowFiniteStateMachineMultiModeComponentHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.DataFlowFiniteStateMachineMultiModeComponentHelper.type ();
  }

}
