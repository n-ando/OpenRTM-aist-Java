package RTC;


/**
* RTC/ComponentActionOperations.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 11��46��38�b JST
*/


/*!
   * @brief LightweightRTC::ConponentAction interface
   */
public interface ComponentActionOperations 
{
  int attach_executioncontext (RTC.ExecutionContext exec_context);
  RTC.ReturnCode_t detach_executioncontext (int ec_id);
  RTC.ReturnCode_t on_initialize ();
  RTC.ReturnCode_t on_finalize ();
  RTC.ReturnCode_t on_startup (int ec_id);
  RTC.ReturnCode_t on_shutdown (int ec_id);
  RTC.ReturnCode_t on_activated (int ec_id);
  RTC.ReturnCode_t on_deactivated (int ec_id);
  RTC.ReturnCode_t on_aborting (int ec_id);
  RTC.ReturnCode_t on_error (int ec_id);
  RTC.ReturnCode_t on_reset (int ec_id);
} // interface ComponentActionOperations
