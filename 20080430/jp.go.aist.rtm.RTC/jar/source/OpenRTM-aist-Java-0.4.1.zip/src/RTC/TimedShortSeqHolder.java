package RTC;

/**
* RTC/TimedShortSeqHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/BasicDataType.idl
* 2008�N8��20�� 11��46��39�b JST
*/

public final class TimedShortSeqHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.TimedShortSeq value = null;

  public TimedShortSeqHolder ()
  {
  }

  public TimedShortSeqHolder (RTC.TimedShortSeq initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.TimedShortSeqHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.TimedShortSeqHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.TimedShortSeqHelper.type ();
  }

}
