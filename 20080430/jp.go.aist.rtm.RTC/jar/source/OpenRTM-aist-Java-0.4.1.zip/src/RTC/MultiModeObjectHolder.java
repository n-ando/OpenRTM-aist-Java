package RTC;

/**
* RTC/MultiModeObjectHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 11��46��38�b JST
*/


/*!
   * @brief ExecutionSemantics::MultiModeObject interface
   */
public final class MultiModeObjectHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.MultiModeObject value = null;

  public MultiModeObjectHolder ()
  {
  }

  public MultiModeObjectHolder (RTC.MultiModeObject initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.MultiModeObjectHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.MultiModeObjectHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.MultiModeObjectHelper.type ();
  }

}
