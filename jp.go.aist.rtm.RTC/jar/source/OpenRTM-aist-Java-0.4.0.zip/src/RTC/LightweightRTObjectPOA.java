package RTC;


/**
* RTC/LightweightRTObjectPOA.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 13��23��53�b JST
*/


/*!
   * @brief LightweightRTC::LightweightRTObject interface
   */
public abstract class LightweightRTObjectPOA extends org.omg.PortableServer.Servant
 implements RTC.LightweightRTObjectOperations, org.omg.CORBA.portable.InvokeHandler
{

  // Constructors

  private static java.util.Hashtable _methods = new java.util.Hashtable ();
  static
  {
    _methods.put ("initialize", new java.lang.Integer (0));
    _methods.put ("finalize", new java.lang.Integer (1));
    _methods.put ("exit", new java.lang.Integer (2));
    _methods.put ("is_alive", new java.lang.Integer (3));
    _methods.put ("get_contexts", new java.lang.Integer (4));
    _methods.put ("get_context", new java.lang.Integer (5));
    _methods.put ("attach_executioncontext", new java.lang.Integer (6));
    _methods.put ("detach_executioncontext", new java.lang.Integer (7));
    _methods.put ("on_initialize", new java.lang.Integer (8));
    _methods.put ("on_finalize", new java.lang.Integer (9));
    _methods.put ("on_startup", new java.lang.Integer (10));
    _methods.put ("on_shutdown", new java.lang.Integer (11));
    _methods.put ("on_activated", new java.lang.Integer (12));
    _methods.put ("on_deactivated", new java.lang.Integer (13));
    _methods.put ("on_aborting", new java.lang.Integer (14));
    _methods.put ("on_error", new java.lang.Integer (15));
    _methods.put ("on_reset", new java.lang.Integer (16));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (String $method,
                                org.omg.CORBA.portable.InputStream in,
                                org.omg.CORBA.portable.ResponseHandler $rh)
  {
    org.omg.CORBA.portable.OutputStream out = null;
    java.lang.Integer __method = (java.lang.Integer)_methods.get ($method);
    if (__method == null)
      throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);

    switch (__method.intValue ())
    {
       case 0:  // RTC/LightweightRTObject/initialize
       {
         RTC.ReturnCode_t $result = null;
         $result = this.initialize ();
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 1:  // RTC/LightweightRTObject/_finalize
       {
         RTC.ReturnCode_t $result = null;
         $result = this._finalize ();
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 2:  // RTC/LightweightRTObject/exit
       {
         RTC.ReturnCode_t $result = null;
         $result = this.exit ();
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 3:  // RTC/LightweightRTObject/is_alive
       {
         boolean $result = false;
         $result = this.is_alive ();
         out = $rh.createReply();
         out.write_boolean ($result);
         break;
       }

       case 4:  // RTC/LightweightRTObject/get_contexts
       {
         RTC.ExecutionContext $result[] = null;
         $result = this.get_contexts ();
         out = $rh.createReply();
         RTC.ExecutionContextListHelper.write (out, $result);
         break;
       }

       case 5:  // RTC/LightweightRTObject/get_context
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ExecutionContext $result = null;
         $result = this.get_context (ec_id);
         out = $rh.createReply();
         RTC.ExecutionContextHelper.write (out, $result);
         break;
       }

       case 6:  // RTC/ComponentAction/attach_executioncontext
       {
         RTC.ExecutionContext exec_context = RTC.ExecutionContextHelper.read (in);
         int $result = (int)0;
         $result = this.attach_executioncontext (exec_context);
         out = $rh.createReply();
         out.write_long ($result);
         break;
       }

       case 7:  // RTC/ComponentAction/detach_executioncontext
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.detach_executioncontext (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 8:  // RTC/ComponentAction/on_initialize
       {
         RTC.ReturnCode_t $result = null;
         $result = this.on_initialize ();
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 9:  // RTC/ComponentAction/on_finalize
       {
         RTC.ReturnCode_t $result = null;
         $result = this.on_finalize ();
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 10:  // RTC/ComponentAction/on_startup
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_startup (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 11:  // RTC/ComponentAction/on_shutdown
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_shutdown (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 12:  // RTC/ComponentAction/on_activated
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_activated (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 13:  // RTC/ComponentAction/on_deactivated
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_deactivated (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 14:  // RTC/ComponentAction/on_aborting
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_aborting (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 15:  // RTC/ComponentAction/on_error
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_error (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 16:  // RTC/ComponentAction/on_reset
       {
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.on_reset (ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       default:
         throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
    }

    return out;
  } // _invoke

  // Type-specific CORBA::Object operations
  private static String[] __ids = {
    "IDL:omg.org/RTC/LightweightRTObject:1.0", 
    "IDL:omg.org/RTC/ComponentAction:1.0"};

  public String[] _all_interfaces (org.omg.PortableServer.POA poa, byte[] objectId)
  {
    return (String[])__ids.clone ();
  }

  public LightweightRTObject _this() 
  {
    return LightweightRTObjectHelper.narrow(
    super._this_object());
  }

  public LightweightRTObject _this(org.omg.CORBA.ORB orb) 
  {
    return LightweightRTObjectHelper.narrow(
    super._this_object(orb));
  }


} // class LightweightRTObjectPOA
