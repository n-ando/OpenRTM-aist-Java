package RTC;

/**
* RTC/ExecutionContextHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 13��23��53�b JST
*/


/*!
   * @brief LightweightRTC::ExecutionContext interface
   */
public final class ExecutionContextHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.ExecutionContext value = null;

  public ExecutionContextHolder ()
  {
  }

  public ExecutionContextHolder (RTC.ExecutionContext initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.ExecutionContextHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.ExecutionContextHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.ExecutionContextHelper.type ();
  }

}
