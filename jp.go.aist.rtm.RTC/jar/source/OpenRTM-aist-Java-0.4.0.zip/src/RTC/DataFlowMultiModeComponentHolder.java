package RTC;

/**
* RTC/DataFlowMultiModeComponentHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 13��23��53�b JST
*/

public final class DataFlowMultiModeComponentHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.DataFlowMultiModeComponent value = null;

  public DataFlowMultiModeComponentHolder ()
  {
  }

  public DataFlowMultiModeComponentHolder (RTC.DataFlowMultiModeComponent initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.DataFlowMultiModeComponentHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.DataFlowMultiModeComponentHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.DataFlowMultiModeComponentHelper.type ();
  }

}
