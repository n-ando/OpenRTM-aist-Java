package RTC;

/**
* RTC/RTObjectHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 13��23��53�b JST
*/


/*!
   * @brief Introspection::RTObject interface
   */
public final class RTObjectHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.RTObject value = null;

  public RTObjectHolder ()
  {
  }

  public RTObjectHolder (RTC.RTObject initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.RTObjectHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.RTObjectHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.RTObjectHelper.type ();
  }

}
