package RTC;

/**
* RTC/DataFlowFiniteStateMachineComponentHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 13��23��53�b JST
*/

public final class DataFlowFiniteStateMachineComponentHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.DataFlowFiniteStateMachineComponent value = null;

  public DataFlowFiniteStateMachineComponentHolder ()
  {
  }

  public DataFlowFiniteStateMachineComponentHolder (RTC.DataFlowFiniteStateMachineComponent initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.DataFlowFiniteStateMachineComponentHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.DataFlowFiniteStateMachineComponentHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.DataFlowFiniteStateMachineComponentHelper.type ();
  }

}
