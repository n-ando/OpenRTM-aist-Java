package RTC;

/**
* RTC/TimedFloatSeqHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/BasicDataType.idl
* 2008�N8��20�� 13��23��54�b JST
*/

public final class TimedFloatSeqHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.TimedFloatSeq value = null;

  public TimedFloatSeqHolder ()
  {
  }

  public TimedFloatSeqHolder (RTC.TimedFloatSeq initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.TimedFloatSeqHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.TimedFloatSeqHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.TimedFloatSeqHelper.type ();
  }

}
