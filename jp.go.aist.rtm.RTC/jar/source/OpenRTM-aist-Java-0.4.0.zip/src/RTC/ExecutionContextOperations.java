package RTC;


/**
* RTC/ExecutionContextOperations.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 13��23��53�b JST
*/


/*!
   * @brief LightweightRTC::ExecutionContext interface
   */
public interface ExecutionContextOperations 
{
  boolean is_running ();
  RTC.ReturnCode_t start ();
  RTC.ReturnCode_t stop ();
  double get_rate ();
  RTC.ReturnCode_t set_rate (double rate);
  RTC.ReturnCode_t activate_component (RTC.LightweightRTObject comp);
  RTC.ReturnCode_t deactivate_component (RTC.LightweightRTObject comp);
  RTC.ReturnCode_t reset_component (RTC.LightweightRTObject comp);
  RTC.LifeCycleState get_component_state (RTC.LightweightRTObject comp);
  RTC.ExecutionKind get_kind ();
  RTC.ReturnCode_t add (RTC.LightweightRTObject comp);
  RTC.ReturnCode_t remove (RTC.LightweightRTObject comp);
} // interface ExecutionContextOperations
