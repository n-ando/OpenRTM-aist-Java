package RTC;


/**
* RTC/ReturnCode_t.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 13��23��53�b JST
*/


/*!
   * @brief LightweightRTC::ReturnCode_t enumeration
   */
public class ReturnCode_t implements org.omg.CORBA.portable.IDLEntity
{
  private        int __value;
  private static int __size = 6;
  private static RTC.ReturnCode_t[] __array = new RTC.ReturnCode_t [__size];

  public static final int _RTC_OK = 0;
  public static final RTC.ReturnCode_t RTC_OK = new RTC.ReturnCode_t(_RTC_OK);
  public static final int _RTC_ERROR = 1;
  public static final RTC.ReturnCode_t RTC_ERROR = new RTC.ReturnCode_t(_RTC_ERROR);
  public static final int _BAD_PARAMETER = 2;
  public static final RTC.ReturnCode_t BAD_PARAMETER = new RTC.ReturnCode_t(_BAD_PARAMETER);
  public static final int _UNSUPPORTED = 3;
  public static final RTC.ReturnCode_t UNSUPPORTED = new RTC.ReturnCode_t(_UNSUPPORTED);
  public static final int _OUT_OF_RESOURCES = 4;
  public static final RTC.ReturnCode_t OUT_OF_RESOURCES = new RTC.ReturnCode_t(_OUT_OF_RESOURCES);
  public static final int _PRECONDITION_NOT_MET = 5;
  public static final RTC.ReturnCode_t PRECONDITION_NOT_MET = new RTC.ReturnCode_t(_PRECONDITION_NOT_MET);

  public int value ()
  {
    return __value;
  }

  public static RTC.ReturnCode_t from_int (int value)
  {
    if (value >= 0 && value < __size)
      return __array[value];
    else
      throw new org.omg.CORBA.BAD_PARAM ();
  }

  protected ReturnCode_t (int value)
  {
    __value = value;
    __array[__value] = this;
  }
} // class ReturnCode_t
