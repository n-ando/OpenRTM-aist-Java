package RTC;


/**
* RTC/ExecutionContextPOA.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 13��23��53�b JST
*/


/*!
   * @brief LightweightRTC::ExecutionContext interface
   */
public abstract class ExecutionContextPOA extends org.omg.PortableServer.Servant
 implements RTC.ExecutionContextOperations, org.omg.CORBA.portable.InvokeHandler
{

  // Constructors

  private static java.util.Hashtable _methods = new java.util.Hashtable ();
  static
  {
    _methods.put ("is_running", new java.lang.Integer (0));
    _methods.put ("start", new java.lang.Integer (1));
    _methods.put ("stop", new java.lang.Integer (2));
    _methods.put ("get_rate", new java.lang.Integer (3));
    _methods.put ("set_rate", new java.lang.Integer (4));
    _methods.put ("activate_component", new java.lang.Integer (5));
    _methods.put ("deactivate_component", new java.lang.Integer (6));
    _methods.put ("reset_component", new java.lang.Integer (7));
    _methods.put ("get_component_state", new java.lang.Integer (8));
    _methods.put ("get_kind", new java.lang.Integer (9));
    _methods.put ("add", new java.lang.Integer (10));
    _methods.put ("remove", new java.lang.Integer (11));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (String $method,
                                org.omg.CORBA.portable.InputStream in,
                                org.omg.CORBA.portable.ResponseHandler $rh)
  {
    org.omg.CORBA.portable.OutputStream out = null;
    java.lang.Integer __method = (java.lang.Integer)_methods.get ($method);
    if (__method == null)
      throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);

    switch (__method.intValue ())
    {
       case 0:  // RTC/ExecutionContext/is_running
       {
         boolean $result = false;
         $result = this.is_running ();
         out = $rh.createReply();
         out.write_boolean ($result);
         break;
       }

       case 1:  // RTC/ExecutionContext/start
       {
         RTC.ReturnCode_t $result = null;
         $result = this.start ();
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 2:  // RTC/ExecutionContext/stop
       {
         RTC.ReturnCode_t $result = null;
         $result = this.stop ();
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 3:  // RTC/ExecutionContext/get_rate
       {
         double $result = (double)0;
         $result = this.get_rate ();
         out = $rh.createReply();
         out.write_double ($result);
         break;
       }

       case 4:  // RTC/ExecutionContext/set_rate
       {
         double rate = in.read_double ();
         RTC.ReturnCode_t $result = null;
         $result = this.set_rate (rate);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 5:  // RTC/ExecutionContext/activate_component
       {
         RTC.LightweightRTObject comp = RTC.LightweightRTObjectHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.activate_component (comp);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 6:  // RTC/ExecutionContext/deactivate_component
       {
         RTC.LightweightRTObject comp = RTC.LightweightRTObjectHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.deactivate_component (comp);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 7:  // RTC/ExecutionContext/reset_component
       {
         RTC.LightweightRTObject comp = RTC.LightweightRTObjectHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.reset_component (comp);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 8:  // RTC/ExecutionContext/get_component_state
       {
         RTC.LightweightRTObject comp = RTC.LightweightRTObjectHelper.read (in);
         RTC.LifeCycleState $result = null;
         $result = this.get_component_state (comp);
         out = $rh.createReply();
         RTC.LifeCycleStateHelper.write (out, $result);
         break;
       }

       case 9:  // RTC/ExecutionContext/get_kind
       {
         RTC.ExecutionKind $result = null;
         $result = this.get_kind ();
         out = $rh.createReply();
         RTC.ExecutionKindHelper.write (out, $result);
         break;
       }

       case 10:  // RTC/ExecutionContext/add
       {
         RTC.LightweightRTObject comp = RTC.LightweightRTObjectHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.add (comp);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       case 11:  // RTC/ExecutionContext/remove
       {
         RTC.LightweightRTObject comp = RTC.LightweightRTObjectHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.remove (comp);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       default:
         throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
    }

    return out;
  } // _invoke

  // Type-specific CORBA::Object operations
  private static String[] __ids = {
    "IDL:omg.org/RTC/ExecutionContext:1.0"};

  public String[] _all_interfaces (org.omg.PortableServer.POA poa, byte[] objectId)
  {
    return (String[])__ids.clone ();
  }

  public ExecutionContext _this() 
  {
    return ExecutionContextHelper.narrow(
    super._this_object());
  }

  public ExecutionContext _this(org.omg.CORBA.ORB orb) 
  {
    return ExecutionContextHelper.narrow(
    super._this_object(orb));
  }


} // class ExecutionContextPOA
