package RTC;


/**
* RTC/ComponentProfile.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 13��23��53�b JST
*/

public final class ComponentProfile implements org.omg.CORBA.portable.IDLEntity
{
  public String instance_name = null;
  public String type_name = null;
  public String description = null;
  public String version = null;
  public String vendor = null;
  public String category = null;
  public RTC.PortProfile port_profiles[] = null;
  public RTC.RTObject parent = null;
  public _SDOPackage.NameValue properties[] = null;

  public ComponentProfile ()
  {
  } // ctor

  public ComponentProfile (String _instance_name, String _type_name, String _description, String _version, String _vendor, String _category, RTC.PortProfile[] _port_profiles, RTC.RTObject _parent, _SDOPackage.NameValue[] _properties)
  {
    instance_name = _instance_name;
    type_name = _type_name;
    description = _description;
    version = _version;
    vendor = _vendor;
    category = _category;
    port_profiles = _port_profiles;
    parent = _parent;
    properties = _properties;
  } // ctor

} // class ComponentProfile
