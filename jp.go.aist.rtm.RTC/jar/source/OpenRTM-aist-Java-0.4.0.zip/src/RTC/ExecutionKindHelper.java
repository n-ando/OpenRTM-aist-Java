package RTC;


/**
* RTC/ExecutionKindHelper.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 13��23��53�b JST
*/


/*!
   * @brief LightweightRTC::ExecutionKind enumeration
   */
abstract public class ExecutionKindHelper
{
  private static String  _id = "IDL:omg.org/RTC/ExecutionKind:1.0";

  public static void insert (org.omg.CORBA.Any a, RTC.ExecutionKind that)
  {
    org.omg.CORBA.portable.OutputStream out = a.create_output_stream ();
    a.type (type ());
    write (out, that);
    a.read_value (out.create_input_stream (), type ());
  }

  public static RTC.ExecutionKind extract (org.omg.CORBA.Any a)
  {
    return read (a.create_input_stream ());
  }

  private static org.omg.CORBA.TypeCode __typeCode = null;
  synchronized public static org.omg.CORBA.TypeCode type ()
  {
    if (__typeCode == null)
    {
      __typeCode = org.omg.CORBA.ORB.init ().create_enum_tc (RTC.ExecutionKindHelper.id (), "ExecutionKind", new String[] { "PERIODIC", "EVENT_DRIVEN", "OTHER"} );
    }
    return __typeCode;
  }

  public static String id ()
  {
    return _id;
  }

  public static RTC.ExecutionKind read (org.omg.CORBA.portable.InputStream istream)
  {
    return RTC.ExecutionKind.from_int (istream.read_long ());
  }

  public static void write (org.omg.CORBA.portable.OutputStream ostream, RTC.ExecutionKind value)
  {
    ostream.write_long (value.value ());
  }

}
