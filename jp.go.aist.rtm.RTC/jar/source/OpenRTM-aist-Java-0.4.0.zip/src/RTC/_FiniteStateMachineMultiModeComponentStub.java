package RTC;


/**
* RTC/_FiniteStateMachineMultiModeComponentStub.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 13��23��53�b JST
*/

public class _FiniteStateMachineMultiModeComponentStub extends org.omg.CORBA.portable.ObjectImpl implements RTC.FiniteStateMachineMultiModeComponent
{

  public RTC.ComponentProfile get_component_profile ()
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_component_profile", true);
                $in = _invoke ($out);
                RTC.ComponentProfile $result = RTC.ComponentProfileHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_component_profile (        );
            } finally {
                _releaseReply ($in);
            }
  } // get_component_profile

  public RTC.Port[] get_ports ()
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_ports", true);
                $in = _invoke ($out);
                RTC.Port $result[] = RTC.PortListHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_ports (        );
            } finally {
                _releaseReply ($in);
            }
  } // get_ports

  public RTC.ExecutionContextService[] get_execution_context_services ()
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_execution_context_services", true);
                $in = _invoke ($out);
                RTC.ExecutionContextService $result[] = RTC.ExecutionContextServiceListHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_execution_context_services (        );
            } finally {
                _releaseReply ($in);
            }
  } // get_execution_context_services

  public RTC.ReturnCode_t initialize ()
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("initialize", true);
                $in = _invoke ($out);
                RTC.ReturnCode_t $result = RTC.ReturnCode_tHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return initialize (        );
            } finally {
                _releaseReply ($in);
            }
  } // initialize

  public RTC.ReturnCode_t _finalize ()
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("finalize", true);
                $in = _invoke ($out);
                RTC.ReturnCode_t $result = RTC.ReturnCode_tHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return _finalize (        );
            } finally {
                _releaseReply ($in);
            }
  } // _finalize

  public RTC.ReturnCode_t exit ()
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("exit", true);
                $in = _invoke ($out);
                RTC.ReturnCode_t $result = RTC.ReturnCode_tHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return exit (        );
            } finally {
                _releaseReply ($in);
            }
  } // exit

  public boolean is_alive ()
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("is_alive", true);
                $in = _invoke ($out);
                boolean $result = $in.read_boolean ();
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return is_alive (        );
            } finally {
                _releaseReply ($in);
            }
  } // is_alive

  public RTC.ExecutionContext[] get_contexts ()
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_contexts", true);
                $in = _invoke ($out);
                RTC.ExecutionContext $result[] = RTC.ExecutionContextListHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_contexts (        );
            } finally {
                _releaseReply ($in);
            }
  } // get_contexts

  public RTC.ExecutionContext get_context (int ec_id)
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_context", true);
                RTC.UniqueIdHelper.write ($out, ec_id);
                $in = _invoke ($out);
                RTC.ExecutionContext $result = RTC.ExecutionContextHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_context (ec_id        );
            } finally {
                _releaseReply ($in);
            }
  } // get_context

  public int attach_executioncontext (RTC.ExecutionContext exec_context)
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("attach_executioncontext", true);
                RTC.ExecutionContextHelper.write ($out, exec_context);
                $in = _invoke ($out);
                int $result = RTC.UniqueIdHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return attach_executioncontext (exec_context        );
            } finally {
                _releaseReply ($in);
            }
  } // attach_executioncontext

  public RTC.ReturnCode_t detach_executioncontext (int ec_id)
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("detach_executioncontext", true);
                RTC.UniqueIdHelper.write ($out, ec_id);
                $in = _invoke ($out);
                RTC.ReturnCode_t $result = RTC.ReturnCode_tHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return detach_executioncontext (ec_id        );
            } finally {
                _releaseReply ($in);
            }
  } // detach_executioncontext

  public RTC.ReturnCode_t on_initialize ()
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("on_initialize", true);
                $in = _invoke ($out);
                RTC.ReturnCode_t $result = RTC.ReturnCode_tHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return on_initialize (        );
            } finally {
                _releaseReply ($in);
            }
  } // on_initialize

  public RTC.ReturnCode_t on_finalize ()
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("on_finalize", true);
                $in = _invoke ($out);
                RTC.ReturnCode_t $result = RTC.ReturnCode_tHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return on_finalize (        );
            } finally {
                _releaseReply ($in);
            }
  } // on_finalize

  public RTC.ReturnCode_t on_startup (int ec_id)
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("on_startup", true);
                RTC.UniqueIdHelper.write ($out, ec_id);
                $in = _invoke ($out);
                RTC.ReturnCode_t $result = RTC.ReturnCode_tHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return on_startup (ec_id        );
            } finally {
                _releaseReply ($in);
            }
  } // on_startup

  public RTC.ReturnCode_t on_shutdown (int ec_id)
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("on_shutdown", true);
                RTC.UniqueIdHelper.write ($out, ec_id);
                $in = _invoke ($out);
                RTC.ReturnCode_t $result = RTC.ReturnCode_tHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return on_shutdown (ec_id        );
            } finally {
                _releaseReply ($in);
            }
  } // on_shutdown

  public RTC.ReturnCode_t on_activated (int ec_id)
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("on_activated", true);
                RTC.UniqueIdHelper.write ($out, ec_id);
                $in = _invoke ($out);
                RTC.ReturnCode_t $result = RTC.ReturnCode_tHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return on_activated (ec_id        );
            } finally {
                _releaseReply ($in);
            }
  } // on_activated

  public RTC.ReturnCode_t on_deactivated (int ec_id)
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("on_deactivated", true);
                RTC.UniqueIdHelper.write ($out, ec_id);
                $in = _invoke ($out);
                RTC.ReturnCode_t $result = RTC.ReturnCode_tHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return on_deactivated (ec_id        );
            } finally {
                _releaseReply ($in);
            }
  } // on_deactivated

  public RTC.ReturnCode_t on_aborting (int ec_id)
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("on_aborting", true);
                RTC.UniqueIdHelper.write ($out, ec_id);
                $in = _invoke ($out);
                RTC.ReturnCode_t $result = RTC.ReturnCode_tHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return on_aborting (ec_id        );
            } finally {
                _releaseReply ($in);
            }
  } // on_aborting

  public RTC.ReturnCode_t on_error (int ec_id)
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("on_error", true);
                RTC.UniqueIdHelper.write ($out, ec_id);
                $in = _invoke ($out);
                RTC.ReturnCode_t $result = RTC.ReturnCode_tHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return on_error (ec_id        );
            } finally {
                _releaseReply ($in);
            }
  } // on_error

  public RTC.ReturnCode_t on_reset (int ec_id)
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("on_reset", true);
                RTC.UniqueIdHelper.write ($out, ec_id);
                $in = _invoke ($out);
                RTC.ReturnCode_t $result = RTC.ReturnCode_tHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return on_reset (ec_id        );
            } finally {
                _releaseReply ($in);
            }
  } // on_reset

  public String get_sdo_id () throws _SDOPackage.NotAvailable, _SDOPackage.InternalError
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_sdo_id", true);
                $in = _invoke ($out);
                String $result = _SDOPackage.UniqueIdentifierHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                if (_id.equals ("IDL:org.omg/_SDOPackage/NotAvailable:1.0"))
                    throw _SDOPackage.NotAvailableHelper.read ($in);
                else if (_id.equals ("IDL:org.omg/_SDOPackage/InternalError:1.0"))
                    throw _SDOPackage.InternalErrorHelper.read ($in);
                else
                    throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_sdo_id (        );
            } finally {
                _releaseReply ($in);
            }
  } // get_sdo_id

  public String get_sdo_type () throws _SDOPackage.NotAvailable, _SDOPackage.InternalError
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_sdo_type", true);
                $in = _invoke ($out);
                String $result = $in.read_string ();
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                if (_id.equals ("IDL:org.omg/_SDOPackage/NotAvailable:1.0"))
                    throw _SDOPackage.NotAvailableHelper.read ($in);
                else if (_id.equals ("IDL:org.omg/_SDOPackage/InternalError:1.0"))
                    throw _SDOPackage.InternalErrorHelper.read ($in);
                else
                    throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_sdo_type (        );
            } finally {
                _releaseReply ($in);
            }
  } // get_sdo_type

  public _SDOPackage.DeviceProfile get_device_profile () throws _SDOPackage.NotAvailable, _SDOPackage.InternalError
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_device_profile", true);
                $in = _invoke ($out);
                _SDOPackage.DeviceProfile $result = _SDOPackage.DeviceProfileHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                if (_id.equals ("IDL:org.omg/_SDOPackage/NotAvailable:1.0"))
                    throw _SDOPackage.NotAvailableHelper.read ($in);
                else if (_id.equals ("IDL:org.omg/_SDOPackage/InternalError:1.0"))
                    throw _SDOPackage.InternalErrorHelper.read ($in);
                else
                    throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_device_profile (        );
            } finally {
                _releaseReply ($in);
            }
  } // get_device_profile

  public _SDOPackage.ServiceProfile[] get_service_profiles () throws _SDOPackage.NotAvailable, _SDOPackage.InternalError
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_service_profiles", true);
                $in = _invoke ($out);
                _SDOPackage.ServiceProfile $result[] = _SDOPackage.ServiceProfileListHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                if (_id.equals ("IDL:org.omg/_SDOPackage/NotAvailable:1.0"))
                    throw _SDOPackage.NotAvailableHelper.read ($in);
                else if (_id.equals ("IDL:org.omg/_SDOPackage/InternalError:1.0"))
                    throw _SDOPackage.InternalErrorHelper.read ($in);
                else
                    throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_service_profiles (        );
            } finally {
                _releaseReply ($in);
            }
  } // get_service_profiles

  public _SDOPackage.ServiceProfile get_service_profile (String id) throws _SDOPackage.InvalidParameter, _SDOPackage.NotAvailable, _SDOPackage.InternalError
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_service_profile", true);
                _SDOPackage.UniqueIdentifierHelper.write ($out, id);
                $in = _invoke ($out);
                _SDOPackage.ServiceProfile $result = _SDOPackage.ServiceProfileHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                if (_id.equals ("IDL:org.omg/_SDOPackage/InvalidParameter:1.0"))
                    throw _SDOPackage.InvalidParameterHelper.read ($in);
                else if (_id.equals ("IDL:org.omg/_SDOPackage/NotAvailable:1.0"))
                    throw _SDOPackage.NotAvailableHelper.read ($in);
                else if (_id.equals ("IDL:org.omg/_SDOPackage/InternalError:1.0"))
                    throw _SDOPackage.InternalErrorHelper.read ($in);
                else
                    throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_service_profile (id        );
            } finally {
                _releaseReply ($in);
            }
  } // get_service_profile

  public _SDOPackage.SDOService get_sdo_service (String id) throws _SDOPackage.InvalidParameter, _SDOPackage.NotAvailable, _SDOPackage.InternalError
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_sdo_service", true);
                _SDOPackage.UniqueIdentifierHelper.write ($out, id);
                $in = _invoke ($out);
                _SDOPackage.SDOService $result = _SDOPackage.SDOServiceHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                if (_id.equals ("IDL:org.omg/_SDOPackage/InvalidParameter:1.0"))
                    throw _SDOPackage.InvalidParameterHelper.read ($in);
                else if (_id.equals ("IDL:org.omg/_SDOPackage/NotAvailable:1.0"))
                    throw _SDOPackage.NotAvailableHelper.read ($in);
                else if (_id.equals ("IDL:org.omg/_SDOPackage/InternalError:1.0"))
                    throw _SDOPackage.InternalErrorHelper.read ($in);
                else
                    throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_sdo_service (id        );
            } finally {
                _releaseReply ($in);
            }
  } // get_sdo_service

  public _SDOPackage.Configuration get_configuration () throws _SDOPackage.InterfaceNotImplemented, _SDOPackage.NotAvailable, _SDOPackage.InternalError
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_configuration", true);
                $in = _invoke ($out);
                _SDOPackage.Configuration $result = _SDOPackage.ConfigurationHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                if (_id.equals ("IDL:org.omg/_SDOPackage/InterfaceNotImplemented:1.0"))
                    throw _SDOPackage.InterfaceNotImplementedHelper.read ($in);
                else if (_id.equals ("IDL:org.omg/_SDOPackage/NotAvailable:1.0"))
                    throw _SDOPackage.NotAvailableHelper.read ($in);
                else if (_id.equals ("IDL:org.omg/_SDOPackage/InternalError:1.0"))
                    throw _SDOPackage.InternalErrorHelper.read ($in);
                else
                    throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_configuration (        );
            } finally {
                _releaseReply ($in);
            }
  } // get_configuration

  public _SDOPackage.Monitoring get_monitoring () throws _SDOPackage.InterfaceNotImplemented, _SDOPackage.NotAvailable, _SDOPackage.InternalError
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_monitoring", true);
                $in = _invoke ($out);
                _SDOPackage.Monitoring $result = _SDOPackage.MonitoringHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                if (_id.equals ("IDL:org.omg/_SDOPackage/InterfaceNotImplemented:1.0"))
                    throw _SDOPackage.InterfaceNotImplementedHelper.read ($in);
                else if (_id.equals ("IDL:org.omg/_SDOPackage/NotAvailable:1.0"))
                    throw _SDOPackage.NotAvailableHelper.read ($in);
                else if (_id.equals ("IDL:org.omg/_SDOPackage/InternalError:1.0"))
                    throw _SDOPackage.InternalErrorHelper.read ($in);
                else
                    throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_monitoring (        );
            } finally {
                _releaseReply ($in);
            }
  } // get_monitoring

  public _SDOPackage.Organization[] get_organizations () throws _SDOPackage.NotAvailable, _SDOPackage.InternalError
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_organizations", true);
                $in = _invoke ($out);
                _SDOPackage.Organization $result[] = _SDOPackage.OrganizationListHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                if (_id.equals ("IDL:org.omg/_SDOPackage/NotAvailable:1.0"))
                    throw _SDOPackage.NotAvailableHelper.read ($in);
                else if (_id.equals ("IDL:org.omg/_SDOPackage/InternalError:1.0"))
                    throw _SDOPackage.InternalErrorHelper.read ($in);
                else
                    throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_organizations (        );
            } finally {
                _releaseReply ($in);
            }
  } // get_organizations

  public _SDOPackage.NameValue[] get_status_list () throws _SDOPackage.NotAvailable, _SDOPackage.InternalError
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_status_list", true);
                $in = _invoke ($out);
                _SDOPackage.NameValue $result[] = _SDOPackage.NVListHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                if (_id.equals ("IDL:org.omg/_SDOPackage/NotAvailable:1.0"))
                    throw _SDOPackage.NotAvailableHelper.read ($in);
                else if (_id.equals ("IDL:org.omg/_SDOPackage/InternalError:1.0"))
                    throw _SDOPackage.InternalErrorHelper.read ($in);
                else
                    throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_status_list (        );
            } finally {
                _releaseReply ($in);
            }
  } // get_status_list

  public org.omg.CORBA.Any get_status (String name) throws _SDOPackage.InvalidParameter, _SDOPackage.NotAvailable, _SDOPackage.InternalError
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_status", true);
                $out.write_string (name);
                $in = _invoke ($out);
                org.omg.CORBA.Any $result = $in.read_any ();
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                if (_id.equals ("IDL:org.omg/_SDOPackage/InvalidParameter:1.0"))
                    throw _SDOPackage.InvalidParameterHelper.read ($in);
                else if (_id.equals ("IDL:org.omg/_SDOPackage/NotAvailable:1.0"))
                    throw _SDOPackage.NotAvailableHelper.read ($in);
                else if (_id.equals ("IDL:org.omg/_SDOPackage/InternalError:1.0"))
                    throw _SDOPackage.InternalErrorHelper.read ($in);
                else
                    throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_status (name        );
            } finally {
                _releaseReply ($in);
            }
  } // get_status

  public _SDOPackage.Organization[] get_owned_organizations () throws _SDOPackage.NotAvailable
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_owned_organizations", true);
                $in = _invoke ($out);
                _SDOPackage.Organization $result[] = _SDOPackage.OrganizationListHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                if (_id.equals ("IDL:org.omg/_SDOPackage/NotAvailable:1.0"))
                    throw _SDOPackage.NotAvailableHelper.read ($in);
                else
                    throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_owned_organizations (        );
            } finally {
                _releaseReply ($in);
            }
  } // get_owned_organizations

  public RTC.ReturnCode_t on_action (int ec_id)
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("on_action", true);
                RTC.UniqueIdHelper.write ($out, ec_id);
                $in = _invoke ($out);
                RTC.ReturnCode_t $result = RTC.ReturnCode_tHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return on_action (ec_id        );
            } finally {
                _releaseReply ($in);
            }
  } // on_action

  public RTC.Mode get_default_mode ()
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_default_mode", true);
                $in = _invoke ($out);
                RTC.Mode $result = RTC.ModeHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_default_mode (        );
            } finally {
                _releaseReply ($in);
            }
  } // get_default_mode

  public RTC.Mode get_current_mode ()
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_current_mode", true);
                $in = _invoke ($out);
                RTC.Mode $result = RTC.ModeHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_current_mode (        );
            } finally {
                _releaseReply ($in);
            }
  } // get_current_mode

  public RTC.Mode get_current_mode_in_context (int ec_id)
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_current_mode_in_context", true);
                RTC.UniqueIdHelper.write ($out, ec_id);
                $in = _invoke ($out);
                RTC.Mode $result = RTC.ModeHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_current_mode_in_context (ec_id        );
            } finally {
                _releaseReply ($in);
            }
  } // get_current_mode_in_context

  public RTC.Mode get_pending_mode ()
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_pending_mode", true);
                $in = _invoke ($out);
                RTC.Mode $result = RTC.ModeHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_pending_mode (        );
            } finally {
                _releaseReply ($in);
            }
  } // get_pending_mode

  public RTC.Mode get_pending_mode_in_context (int ec_id)
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("get_pending_mode_in_context", true);
                RTC.UniqueIdHelper.write ($out, ec_id);
                $in = _invoke ($out);
                RTC.Mode $result = RTC.ModeHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return get_pending_mode_in_context (ec_id        );
            } finally {
                _releaseReply ($in);
            }
  } // get_pending_mode_in_context

  public RTC.ReturnCode_t set_mode (RTC.Mode new_mode, boolean immediate)
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("set_mode", true);
                RTC.ModeHelper.write ($out, new_mode);
                $out.write_boolean (immediate);
                $in = _invoke ($out);
                RTC.ReturnCode_t $result = RTC.ReturnCode_tHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return set_mode (new_mode, immediate        );
            } finally {
                _releaseReply ($in);
            }
  } // set_mode

  public RTC.ReturnCode_t on_mode_changed (RTC.LightweightRTObject comp, int ec_id)
  {
            org.omg.CORBA.portable.InputStream $in = null;
            try {
                org.omg.CORBA.portable.OutputStream $out = _request ("on_mode_changed", true);
                RTC.LightweightRTObjectHelper.write ($out, comp);
                RTC.UniqueIdHelper.write ($out, ec_id);
                $in = _invoke ($out);
                RTC.ReturnCode_t $result = RTC.ReturnCode_tHelper.read ($in);
                return $result;
            } catch (org.omg.CORBA.portable.ApplicationException $ex) {
                $in = $ex.getInputStream ();
                String _id = $ex.getId ();
                throw new org.omg.CORBA.MARSHAL (_id);
            } catch (org.omg.CORBA.portable.RemarshalException $rm) {
                return on_mode_changed (comp, ec_id        );
            } finally {
                _releaseReply ($in);
            }
  } // on_mode_changed

  // Type-specific CORBA::Object operations
  private static String[] __ids = {
    "IDL:openrtm.aist.go.jp/RTC/FiniteStateMachineMultiModeComponent:1.0", 
    "IDL:omg.org/RTC/RTObject:1.0", 
    "IDL:omg.org/RTC/LightweightRTObject:1.0", 
    "IDL:omg.org/RTC/ComponentAction:1.0", 
    "IDL:org.omg/SDOPackage/SDO:1.0", 
    "IDL:org.omg/SDOPackage/SDOSystemElement:1.0", 
    "IDL:omg.org/RTC/FsmParticipant:1.0", 
    "IDL:omg.org/RTC/FsmParticipantAction:1.0", 
    "IDL:omg.org/RTC/MultiModeObject:1.0", 
    "IDL:omg.org/RTC/ModeCapable:1.0", 
    "IDL:omg.org/RTC/MultiModeComponentAction:1.0"};

  public String[] _ids ()
  {
    return (String[])__ids.clone ();
  }

  private void readObject (java.io.ObjectInputStream s) throws java.io.IOException
  {
     String str = s.readUTF ();
     String[] args = null;
     java.util.Properties props = null;
     org.omg.CORBA.Object obj = org.omg.CORBA.ORB.init (args, props).string_to_object (str);
     org.omg.CORBA.portable.Delegate delegate = ((org.omg.CORBA.portable.ObjectImpl) obj)._get_delegate ();
     _set_delegate (delegate);
  }

  private void writeObject (java.io.ObjectOutputStream s) throws java.io.IOException
  {
     String[] args = null;
     java.util.Properties props = null;
     String str = org.omg.CORBA.ORB.init (args, props).object_to_string (this);
     s.writeUTF (str);
  }
} // class _FiniteStateMachineMultiModeComponentStub
