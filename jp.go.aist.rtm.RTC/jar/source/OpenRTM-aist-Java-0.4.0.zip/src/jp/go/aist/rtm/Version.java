package jp.go.aist.rtm;

/**
 * <p>本OpenRTMに関する情報を格納しています。</p>
 */
public interface Version {

    public static final String openrtm_name = "OpenRTM-aist-0.4.0";
    public static final String openrtm_version = "0.4.0";
    public static final String corba_name = "omniORB";
    
}
