package _SDOPackage;

/**
* _SDOPackage/NotAvailableHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 13��23��53�b JST
*/

public final class NotAvailableHolder implements org.omg.CORBA.portable.Streamable
{
  public _SDOPackage.NotAvailable value = null;

  public NotAvailableHolder ()
  {
  }

  public NotAvailableHolder (_SDOPackage.NotAvailable initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = _SDOPackage.NotAvailableHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    _SDOPackage.NotAvailableHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return _SDOPackage.NotAvailableHelper.type ();
  }

}
