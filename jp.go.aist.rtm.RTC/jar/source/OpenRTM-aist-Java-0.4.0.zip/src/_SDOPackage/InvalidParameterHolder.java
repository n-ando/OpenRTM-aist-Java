package _SDOPackage;

/**
* _SDOPackage/InvalidParameterHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 13��23��53�b JST
*/

public final class InvalidParameterHolder implements org.omg.CORBA.portable.Streamable
{
  public _SDOPackage.InvalidParameter value = null;

  public InvalidParameterHolder ()
  {
  }

  public InvalidParameterHolder (_SDOPackage.InvalidParameter initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = _SDOPackage.InvalidParameterHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    _SDOPackage.InvalidParameterHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return _SDOPackage.InvalidParameterHelper.type ();
  }

}
