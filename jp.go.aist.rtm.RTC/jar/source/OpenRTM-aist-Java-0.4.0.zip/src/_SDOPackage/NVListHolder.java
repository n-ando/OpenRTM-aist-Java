package _SDOPackage;


/**
* _SDOPackage/NVListHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 13��23��53�b JST
*/

public final class NVListHolder implements org.omg.CORBA.portable.Streamable
{
  public _SDOPackage.NameValue value[] = null;

  public NVListHolder ()
  {
  }

  public NVListHolder (_SDOPackage.NameValue[] initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = _SDOPackage.NVListHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    _SDOPackage.NVListHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return _SDOPackage.NVListHelper.type ();
  }

}
