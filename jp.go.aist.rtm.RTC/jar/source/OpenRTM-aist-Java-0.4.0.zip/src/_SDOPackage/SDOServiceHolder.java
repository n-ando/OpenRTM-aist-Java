package _SDOPackage;

/**
* _SDOPackage/SDOServiceHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��20�� 13��23��53�b JST
*/

public final class SDOServiceHolder implements org.omg.CORBA.portable.Streamable
{
  public _SDOPackage.SDOService value = null;

  public SDOServiceHolder ()
  {
  }

  public SDOServiceHolder (_SDOPackage.SDOService initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = _SDOPackage.SDOServiceHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    _SDOPackage.SDOServiceHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return _SDOPackage.SDOServiceHelper.type ();
  }

}
