package jp.go.aist.rtm.RTC.sample;

public class loadSample {
    public void SampleMethod() {
        System.out.println("Sample Method invoked.");
    }

}
