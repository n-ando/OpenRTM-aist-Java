package RTC;


/**
* RTC/FsmObjectPOA.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��1�� 13��55��18�b JST
*/


/*!
   * @brief ExecutionSemantics::FsmObject interface
   */
public abstract class FsmObjectPOA extends org.omg.PortableServer.Servant
 implements RTC.FsmObjectOperations, org.omg.CORBA.portable.InvokeHandler
{

  // Constructors

  private static java.util.Hashtable _methods = new java.util.Hashtable ();
  static
  {
    _methods.put ("stimulate", new java.lang.Integer (0));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (String $method,
                                org.omg.CORBA.portable.InputStream in,
                                org.omg.CORBA.portable.ResponseHandler $rh)
  {
    org.omg.CORBA.portable.OutputStream out = null;
    java.lang.Integer __method = (java.lang.Integer)_methods.get ($method);
    if (__method == null)
      throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);

    switch (__method.intValue ())
    {
       case 0:  // RTC/FsmObject/stimulate
       {
         String message = in.read_string ();
         int ec_id = RTC.UniqueIdHelper.read (in);
         RTC.ReturnCode_t $result = null;
         $result = this.stimulate (message, ec_id);
         out = $rh.createReply();
         RTC.ReturnCode_tHelper.write (out, $result);
         break;
       }

       default:
         throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
    }

    return out;
  } // _invoke

  // Type-specific CORBA::Object operations
  private static String[] __ids = {
    "IDL:omg.org/RTC/FsmObject:1.0"};

  public String[] _all_interfaces (org.omg.PortableServer.POA poa, byte[] objectId)
  {
    return (String[])__ids.clone ();
  }

  public FsmObject _this() 
  {
    return FsmObjectHelper.narrow(
    super._this_object());
  }

  public FsmObject _this(org.omg.CORBA.ORB orb) 
  {
    return FsmObjectHelper.narrow(
    super._this_object(orb));
  }


} // class FsmObjectPOA
