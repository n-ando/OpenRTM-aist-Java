package RTC;


/**
* RTC/OutPortAnyPOA.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/DataPort.idl
* 2008�N8��1�� 13��55��19�b JST
*/

public abstract class OutPortAnyPOA extends org.omg.PortableServer.Servant
 implements RTC.OutPortAnyOperations, org.omg.CORBA.portable.InvokeHandler
{

  // Constructors

  private static java.util.Hashtable _methods = new java.util.Hashtable ();
  static
  {
    _methods.put ("get", new java.lang.Integer (0));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (String $method,
                                org.omg.CORBA.portable.InputStream in,
                                org.omg.CORBA.portable.ResponseHandler $rh)
  {
    org.omg.CORBA.portable.OutputStream out = null;
    java.lang.Integer __method = (java.lang.Integer)_methods.get ($method);
    if (__method == null)
      throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);

    switch (__method.intValue ())
    {
       case 0:  // RTC/OutPortAny/get
       {
         org.omg.CORBA.Any $result = null;
         $result = this.get ();
         out = $rh.createReply();
         out.write_any ($result);
         break;
       }

       default:
         throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
    }

    return out;
  } // _invoke

  // Type-specific CORBA::Object operations
  private static String[] __ids = {
    "IDL:RTC/OutPortAny:1.0"};

  public String[] _all_interfaces (org.omg.PortableServer.POA poa, byte[] objectId)
  {
    return (String[])__ids.clone ();
  }

  public OutPortAny _this() 
  {
    return OutPortAnyHelper.narrow(
    super._this_object());
  }

  public OutPortAny _this(org.omg.CORBA.ORB orb) 
  {
    return OutPortAnyHelper.narrow(
    super._this_object(orb));
  }


} // class OutPortAnyPOA
