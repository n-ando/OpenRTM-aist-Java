package RTC;

/**
* RTC/TimedBooleanSeqHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/BasicDataType.idl
* 2008�N8��1�� 13��55��19�b JST
*/

public final class TimedBooleanSeqHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.TimedBooleanSeq value = null;

  public TimedBooleanSeqHolder ()
  {
  }

  public TimedBooleanSeqHolder (RTC.TimedBooleanSeq initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.TimedBooleanSeqHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.TimedBooleanSeqHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.TimedBooleanSeqHelper.type ();
  }

}
