package RTC;

/**
* RTC/ExecutionKindHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��1�� 13��55��18�b JST
*/


/*!
   * @brief LightweightRTC::ExecutionKind enumeration
   */
public final class ExecutionKindHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.ExecutionKind value = null;

  public ExecutionKindHolder ()
  {
  }

  public ExecutionKindHolder (RTC.ExecutionKind initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.ExecutionKindHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.ExecutionKindHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.ExecutionKindHelper.type ();
  }

}
