package RTC;

/**
* RTC/FsmParticipantActionHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��1�� 13��55��18�b JST
*/


/*!
   * @brief ExecutionSemantics::FsmParticipantAction interface
   */
public final class FsmParticipantActionHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.FsmParticipantAction value = null;

  public FsmParticipantActionHolder ()
  {
  }

  public FsmParticipantActionHolder (RTC.FsmParticipantAction initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.FsmParticipantActionHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.FsmParticipantActionHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.FsmParticipantActionHelper.type ();
  }

}
