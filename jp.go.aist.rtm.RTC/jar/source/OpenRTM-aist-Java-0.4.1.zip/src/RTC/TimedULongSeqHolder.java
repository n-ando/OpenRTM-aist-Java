package RTC;

/**
* RTC/TimedULongSeqHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/BasicDataType.idl
* 2008�N8��1�� 13��55��19�b JST
*/

public final class TimedULongSeqHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.TimedULongSeq value = null;

  public TimedULongSeqHolder ()
  {
  }

  public TimedULongSeqHolder (RTC.TimedULongSeq initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.TimedULongSeqHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.TimedULongSeqHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.TimedULongSeqHelper.type ();
  }

}
