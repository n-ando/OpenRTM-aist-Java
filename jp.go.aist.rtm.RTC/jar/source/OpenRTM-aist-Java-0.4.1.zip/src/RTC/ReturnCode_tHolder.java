package RTC;

/**
* RTC/ReturnCode_tHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��1�� 13��55��18�b JST
*/


/*!
   * @brief LightweightRTC::ReturnCode_t enumeration
   */
public final class ReturnCode_tHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.ReturnCode_t value = null;

  public ReturnCode_tHolder ()
  {
  }

  public ReturnCode_tHolder (RTC.ReturnCode_t initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.ReturnCode_tHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.ReturnCode_tHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.ReturnCode_tHelper.type ();
  }

}
