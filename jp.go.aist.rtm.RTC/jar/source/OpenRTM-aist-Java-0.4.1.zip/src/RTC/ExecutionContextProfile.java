package RTC;


/**
* RTC/ExecutionContextProfile.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��1�� 13��55��19�b JST
*/

public final class ExecutionContextProfile implements org.omg.CORBA.portable.IDLEntity
{
  public RTC.ExecutionKind kind = null;
  public double rate = (double)0;
  public RTC.RTObject owner = null;
  public RTC.RTObject participants[] = null;
  public _SDOPackage.NameValue properties[] = null;

  public ExecutionContextProfile ()
  {
  } // ctor

  public ExecutionContextProfile (RTC.ExecutionKind _kind, double _rate, RTC.RTObject _owner, RTC.RTObject[] _participants, _SDOPackage.NameValue[] _properties)
  {
    kind = _kind;
    rate = _rate;
    owner = _owner;
    participants = _participants;
    properties = _properties;
  } // ctor

} // class ExecutionContextProfile
