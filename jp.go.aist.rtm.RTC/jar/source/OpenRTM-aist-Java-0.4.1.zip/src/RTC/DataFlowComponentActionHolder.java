package RTC;

/**
* RTC/DataFlowComponentActionHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��1�� 13��55��18�b JST
*/


/*!-----------------------------------------------------------
   * ExecutionSemantics Package
   *------------------------------------------------------------/

  /*!
   * @brief ExecutionSemantics::DataFlowComponentAction interface
   */
public final class DataFlowComponentActionHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.DataFlowComponentAction value = null;

  public DataFlowComponentActionHolder ()
  {
  }

  public DataFlowComponentActionHolder (RTC.DataFlowComponentAction initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.DataFlowComponentActionHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.DataFlowComponentActionHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.DataFlowComponentActionHelper.type ();
  }

}
