package RTC;

/**
* RTC/PortInterfacePolarityHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��1�� 13��55��19�b JST
*/


/*!
   * @brief Introspection::PortInterfacePolarity enumeration
   */
public final class PortInterfacePolarityHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.PortInterfacePolarity value = null;

  public PortInterfacePolarityHolder ()
  {
  }

  public PortInterfacePolarityHolder (RTC.PortInterfacePolarity initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.PortInterfacePolarityHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.PortInterfacePolarityHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.PortInterfacePolarityHelper.type ();
  }

}
