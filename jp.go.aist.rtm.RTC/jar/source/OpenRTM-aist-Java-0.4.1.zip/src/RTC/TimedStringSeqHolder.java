package RTC;

/**
* RTC/TimedStringSeqHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/BasicDataType.idl
* 2008�N8��1�� 13��55��19�b JST
*/

public final class TimedStringSeqHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.TimedStringSeq value = null;

  public TimedStringSeqHolder ()
  {
  }

  public TimedStringSeqHolder (RTC.TimedStringSeq initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.TimedStringSeqHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.TimedStringSeqHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.TimedStringSeqHelper.type ();
  }

}
