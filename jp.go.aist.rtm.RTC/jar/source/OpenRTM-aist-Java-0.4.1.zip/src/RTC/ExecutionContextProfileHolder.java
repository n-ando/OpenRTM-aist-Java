package RTC;

/**
* RTC/ExecutionContextProfileHolder.java .
* IDL-to-Java �R���p�C�� (�|�[�^�u��), �o�[�W���� "3.1" �Ő���
* ������: idl/OpenRTM.idl
* 2008�N8��1�� 13��55��19�b JST
*/

public final class ExecutionContextProfileHolder implements org.omg.CORBA.portable.Streamable
{
  public RTC.ExecutionContextProfile value = null;

  public ExecutionContextProfileHolder ()
  {
  }

  public ExecutionContextProfileHolder (RTC.ExecutionContextProfile initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RTC.ExecutionContextProfileHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RTC.ExecutionContextProfileHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RTC.ExecutionContextProfileHelper.type ();
  }

}
